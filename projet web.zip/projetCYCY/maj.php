<?php

    require("connexion_db.php");

    $ok = "";
    $modele = "";
    $disponibilite = "";


    if($_SERVER["REQUEST_METHOD"] == "POST"){

        $modele = htmlspecialchars($_POST["modele"]);
        $disponibilite = htmlspecialchars($_POST['disponibilite']);

        
        $sql = "INSERT INTO maj(modele,disponibilite) values('$modele','$disponibilite')";
        
        $result = mysqli_query($conn, $sql);

        $ok = "Enregistrement réussi !!";
        
    }
    
    mysqli_close($conn);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="css/maj.css">
    <title>Espace Propriétaire</title>
</head>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="logo">
                        <h1><a>SBS-sarl</a></h1>
                    </div>
                </div>
                <nav class="col-md-8 col-sm-8 col-xs-6">
                    <ul>
                        <li> <a href="index.php">Accueil</a></li>
                        <li> <a href="admin_connected.php">Liste des camions</a></li>
                        <li> <a href="commande.php">Commandes</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- header -->

    <section class="client">
       <center><h2 class="section-title">Ajouter camions</h2></center> 
            <div class="line"><span></span></div>
        <div class="text">
            <p></p>
        </div>
    </section>

    <div class="alignement">
        <div class="form-container">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                <span class="sucess"><?php echo $ok; ?></span>
                <div class="form-group">
                    <label for="exampleInputEmail">Modèle du camion</label>
                    <input type="text" class="form-control" name="modele">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Disponibilité</label>
                    </div>
                    <select class="custom-select" name="disponibilite">
                        <option selected>Choisir</option>
                        <option value="Disponible">Disponible</option>
                        <option value="Indisponible: en panne">Indisponible: en panne</option>
                        <option value="Indisponible: chez un client">Indisponible: chez un client</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-block">Ajouter</button>
            </form>
        </div>
    </div>

    <footer id="footer">
        <ul>
            <li><img src="./images/fb.png" alt="Facebook"> Facebook</li>
            <li><img src="./images/insta.jpg" alt="Instagram"> Instagram</li>
            <li><img src="./images/gmail.png" alt="gmail"> E-mail</li>
        </ul>
        <center><p class="copyright">&copy; Untitled. All rights reserved. Design by SBS-sarl.</p></center>
        
    </footer>
    <script src="js/vendors/jquery-3.3.1.min.js"></script>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
</body>
</html>