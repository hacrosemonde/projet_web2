<?php
    require("connexion_db.php");
    
    require './PHPMailer/src/Exception.php';
    require './PHPMailer/src/PHPMailer.php';
    require './PHPMailer/src/SMTP.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="css/commande.css">
    <title>Espace Propriétaire</title>
</head>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="logo">
                        <h1><a>SBS-sarl</a></h1>
                    </div>
                </div>
                <nav class="col-md-8 col-sm-8 col-xs-6">
                    <ul>
                        <li> <a href="index.php">Accueil</a></li>
                        <li> <a href="admin_connected.php">Liste des camions</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- header -->

    <section class="client">
       <center><h2 class="section-title">Les commandes</h2></center> 
            <div class="line"><span></span></div>
        <div class="text">
            <p></p>
        </div>
    </section>

    <table class="table">
        <thead class="thead-light">
            <tr>
            <th scope="col">Nom</th>
            <th scope="col">Prenoms</th>
            <th scope="col">Email</th>
            <th scope="col">Quantite de sable(tonne)</th>
            <th scope="col">Lieu de livraison</th>
            <th scope="col">Heure de livraison</th>
            <th scope="col">montant</th>
            </tr>
        </thead>
        <tbody>
        <?php

            $query = mysqli_query($conn,"select *from client");

            while($row = mysqli_fetch_assoc($query)) {
                echo '<tr><td>' .$row["nom"]. '</td>';
                echo '<td>' .$row["prenom"]. '</td>';
                echo '<td>' .$row["email"]. '</td>';
                echo '<td>' .$row["quantite"]. '</td>';
                echo '<td>' .$row["lieu"]. '</td>';
                echo '<td>' .$row["heure"]. '</td>';
                echo '<td>' .$row["montant"]. '</td>';
                echo '<td><a href="envoyer_email.php?email=' . $row["email"] . '&quantite=' . $row["quantite"] . '&lieu=' . $row["lieu"] . '&heure=' . $row["heure"] . '&montant=' . $row["montant"] . '">Valider</a></td>';
                '</tr>';
            }
        ?>
        </tbody>
    </table>

    <footer id="footer">
        <ul>
            <li><img src="./images/fb.png" alt="Facebook"> Facebook</li>
            <li><img src="./images/insta.jpg" alt="Instagram"> Instagram</li>
            <li><img src="./images/gmail.png" alt="gmail"> E-mail</li>
        </ul>
        <center><p class="copyright">&copy; Untitled. All rights reserved. Design by SBS-sarl.</p></center>
        
    </footer>
    <script src="js/vendors/jquery-3.3.1.min.js"></script>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
</body>
</html>