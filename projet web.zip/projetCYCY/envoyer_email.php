<?php
#require_once 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';

$mail = new PHPMailer(true);
$mail2 = new PHPMailer(true);

if (isset($_GET['email']) && isset($_GET['quantite']) && isset($_GET['lieu']) && isset($_GET['heure']) && isset($_GET['montant'])) {
    $to = $_GET['email'];
    $subject = "Confirmation de commande";
    $message = "Votre commande a été validée :\n\n";
    $message .= "Quantité : " . $_GET['quantite'] . "\n";
    $message .= "Lieu de livraison : " . $_GET['lieu'] . "\n";
    $message .= "Heure de livraison : " . $_GET['heure'] . "\n";
    $message .= "Montant : " . $_GET['montant'] . " FCFA\n";

    $mail = new PHPMailer(true);

    try {
        $mail->SMTPDebug = SMTP::DEBUG_OFF;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'votre@gmail.com'; // adresse Gmail Propriétaire
        $mail->Password = 'votre_mot_de_passe'; // mot de passe Gmail Propriétaire
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('votre@gmail.com', 'Votre Nom'); //Adresse mail  de l'expéditeur
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        echo "E-mail envoyé avec succès.";
    } catch (Exception $e) {
        echo "Erreur lors de l'envoi de l'e-mail : {$mail->ErrorInfo}";
    }
} else {
    echo "Paramètres manquants.";
}
?>
