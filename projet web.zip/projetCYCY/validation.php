<?php
//connexion à la base de données
$servername = "localhost";
$username = "utilisateur";
$password = "mot_de_passe";
$dbname = "ma_base_de_données";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connexion échouée : ". $conn->connect_error);
}

//Valider la commande
$Idcommande = $_POST['Id_commande'];
$adminComment = $_POST['admin_Comment'];
$statut = 'validée';//changer le statut de la commande en validée

$sql = "UPDATE commandes SET statut = '$statut', admin_Comment = '$adminComment' WHERE IdClient=$Idcommande ";

if($conn->query(sql) === TRUE ) {

    // envoie de la facture par mail
    $to = $_POST['client_email'];
    $subject = "Facture de votre commande";
    $message = "Cher/Chère client(e),\n\n Nous vous remercions pour votre commande. Vous trouverez ci-joint la facture correspondante. 
    \n\n Cordialement, SBS-sarl.";
    $headers = "From : hacrosemonde@gmail.com";
    
    if(mail($to, $subject, $message, $headers)){
        echo "Commande validée et facture envoyée avec succès.";
    }else{
        echo "Erreur lors de l'envoi de la facture par e-mail.";
    }
}else{
    echo "Erreur lors de la validaton de la commande : ". $conn->error;
}

$conn->close();  
>