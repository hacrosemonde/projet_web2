<?php

    require("connexion_db.php");

    $erreur = "";
    $username = "";
    $mdp = "";

    if($_SERVER["REQUEST_METHOD"] == "POST"){

        $username = htmlspecialchars($_POST["username"]);
        $mdp = htmlspecialchars($_POST['password']);
        
        $query = mysqli_query($conn, "SELECT * FROM administrateur WHERE nom = '$username' AND mdp = '$mdp' ");
        
        if(mysqli_num_rows($query) > 0){
            header("location: admin_connected.php");
        } else{    
            $erreur = "Nom d'utilisateur ou mot de passe incorrect !!";
        }
        
    }
    
    mysqli_close($conn);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="css/admin.css">
    <title>Espace Propriétaire</title>
</head>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="logo">
                        <h1><a>SBS-sarl</a></h1>
                    </div>
                </div>
                <nav class="col-md-8 col-sm-8 col-xs-6">
                    <ul>
                        <li> <a href="index.php">Accueil</a></li>
                        <li> <a href="#footer">Nous Contacter</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- header -->

    <section >
        <div class="admin">
            <div class="img">
                <img src="./images/admin.png" alt="" height="150px" width="150px">
            </div> 
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <h1>Espace Propriétaire</h1> 
                <span class="erreur"><?php echo $erreur; ?></span>
                <div class="name-field">
                    <div>
                        <label for="username">Nom utilisateur :</label>
                        <input type="text" name="username" required>
                    </div>
                    <div>
                        <label for="password">Mot de Passe :</label>
                         <input type="password"  name="password" required>
                    </div>
                </div>
                <br><br>
                <button type="submit">Se Connecter</button>
            </form>
        </div>
    </section>
    <br><br> <br><br><br><br><br><br><br>

    <footer id="footer">
        <ul>
            <li><img src="./images/fb.png" alt="Facebook"> Facebook</li>
            <li><img src="./images/insta.jpg" alt="Instagram"> Instagram</li>
            <li><img src="./images/gmail.png" alt="gmail"> E-mail</li>
        </ul>
        <center><p class="copyright">&copy; Untitled. All rights reserved. Design by SBS-sarl.</p></center>
        
    </footer>
    <script src="js/vendors/jquery-3.3.1.min.js"></script>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
</body>
</html>
 
