<?php
    require("connexion_db.php");

    if(isset($_GET['delete'])) {

        $sql = "DELETE FROM maj WHERE modele='".$_GET["delete"]."'";

        mysqli_query($conn,$sql);

    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="css/admin_conn.css">
    <title>Espace Propriétaire</title>
</head>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="logo">
                        <h1><a>SBS-sarl</a></h1>
                    </div>
                </div>
                <nav class="col-md-8 col-sm-8 col-xs-6">
                    <ul>
                        <li> <a href="index.php">Accueil</a></li>
                        <li> <a href="maj.php">Ajouter camion</a></li>
                        <li> <a href="commande.php">Commandes</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- header -->

    <section class="client">
       <center><h2 class="section-title">Liste des camions</h2></center> 
            <div class="line"><span></span></div>
        <div class="text">
            <p></p>
        </div>
    </section>

    <table class="table">
        <thead class="thead-light">
            <tr>
            <th scope="col">Modèle</th>
            <th scope="col">Disponibilité</th>
            </tr>
        </thead>
        <tbody>
        <?php

            $query = mysqli_query($conn,"select *from maj");

            while($row = mysqli_fetch_assoc($query)) {
                echo '<tr><td>' .$row["modele"]. '</td>';
                echo '<td>' .$row["disponibilite"]. '</td>';
                echo '<td><a href="maj_camion.php?update='.$row["modele"].'">Modifier</a></td>';
                echo '<td><a href="?delete='.$row["modele"].'">Supprimer</a></td>';
                '</tr>';
            }
        ?>
        </tbody>
    </table>

    <footer id="footer">
        <ul>
            <li><img src="./images/fb.png" alt="Facebook"> Facebook</li>
            <li><img src="./images/insta.jpg" alt="Instagram"> Instagram</li>
            <li><img src="./images/gmail.png" alt="gmail"> E-mail</li>
        </ul>
        <center><p class="copyright">&copy; Untitled. All rights reserved. Design by SBS-sarl.</p></center>
        
    </footer>
    <script src="js/vendors/jquery-3.3.1.min.js"></script>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
</body>
</html>