<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="css/style.css">
    <title>Accueil</title>
</head>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="logo">
                        <h1><a>SBS-sarl</a></h1>
                    </div>
                </div>
                <nav class="col-md-8 col-sm-8 col-xs-6">
                    <ul>
                        <li> <a href="index.php">Accueil</a></li>
                        <!-- <li> <a href="catalogue.php">Nos Services</a></li> -->
                        <li> <a href="client.php">Espace client</a></li>
                        <li> <a href="#footer">Nous Contacter</a></li>
                        <li> <a href="#propos">A propos</a></li>
                        <li> <a href="admin.php">Espace propriétaire</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- header -->

    <section class="sections home">
        <div class="overlay">
            <center>
                <div class="container">
                    <div class="home-content">
                        <h3 class="home-title">Bienvenue Sur Notre Site</h3>
                    <p class="home-desc">
                        Chez SBS-sarl Commandez et vous êtes servis dans l'immédiat.
                    </p> <br>
                    <button id="propos" class="btn button">Continuer</button>
                    </div>
                </div>
            </center>
           
        </div>
    </section>
    <section class="sections about">
        <div class="container">
            <center>
                <h2 id="propos" class="section-title">A Propos de Nous</h2> <br>
            <div class="line"><span></span></div> <br>
                <p>Parc Auto SBS-sarl(Société de Benne de Sable) disposant de camion de Benne pour les délivrances des chargements de sable.</p>
            </div>
            </center>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="about-info">
                        <h3>Bienvenue à notre parc automobile <span>SBS-sarl.</span></h3> <br>
                        <p class="about-info-desc">    
                            Où nous mettons à votre disposition une flotte 
                            de camions bennes spécialisés dans la livraison de sable. Nos véhicules sont soigneusement 
                            entretenus et équipés pour répondre à vos besoins en matière de transport de matériaux. Que ce soit pour des projets de construction, 
                            d'aménagement paysager ou autres, nos camions bennes sont prêts à assurer des livraisons rapides et efficaces de sable. 
                            Faites confiance à notre parc auto pour des solutions de transport fiables et professionnelles.
                    
                        </p> 
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="about-img">
                        <img src="./images/camion1.jpg" alt="" width="60%" height="60%">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <br><br>
    <!-- footer -->
    <footer id="footer">
        <ul>
            <li><img src="./images/fb.png" alt="Facebook"> Facebook</li>
            <li><img src="./images/insta.jpg" alt="Instagram"> Instagram</li>
            <li><img src="./images/gmail.png" alt="gmail"> E-mail</li>
        </ul>
        <center><p class="copyright">&copy; Untitled. All rights reserved. Design by SBS-sarl.</p></center>
    </footer>
    <!-- footer -->
    <script src="js/vendors/jquery-3.3.1.min.js"></script>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
</body>
</html>