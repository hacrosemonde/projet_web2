<?php

    require("connexion_db.php");

    $message = "";
    $messagesucces = "";
    $nom = "";
    $prenom = "";
    $email = "";
    $quantite = "";
    $lieu = "";
    $heure = "";

    $sql = "SELECT *FROM maj";

    $result = mysqli_query($conn, $sql);


    if($_SERVER["REQUEST_METHOD"] == "POST"){

        $nom = htmlspecialchars($_POST["nom"]);
        $prenom = htmlspecialchars($_POST["prenom"]);
        $email = htmlspecialchars($_POST["email"]);
        $quantite = htmlspecialchars($_POST["quantite"]);
        $lieu = htmlspecialchars($_POST['lieu']);
        $heure = htmlspecialchars($_POST['heure']);

        $sqlMaj = "SELECT * FROM maj WHERE disponibilite = 'Disponible'";
        $resultMaj = mysqli_query($conn, $sqlMaj);

        if ($resultMaj && mysqli_num_rows($resultMaj) > 0) {
            
            $montant = $quantite * 6500;
            $messagesucess = "Commande Effectuée, la facture vous sera envoyé par mail après validation. Montant à payer : $montant FCFA";
            
            echo "<script>
                    alert('$messagesucess');
                </script>";

            $sqlSauvegarde = "INSERT INTO client(nom,prenom,email,quantite,lieu,heure,montant) VALUES ('$nom', '$prenom', '$email', '$quantite', '$lieu', '$heure', '$montant')";
            mysqli_query($conn, $sqlSauvegarde);
    
        
        } else {
            $message = "Aucun camion disponible à cette heure.";

            echo "<script>
                    alert('$message');
                </script>";
        }

        
    }
    
    mysqli_close($conn);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="css/client.css">
    <title>Client</title>
</head>
<body>
    <!-- header -->
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-6">
                    <div class="logo">
                        <h1><a>SBS-sarl</a></h1>
                    </div>
                </div>
                <nav class="col-md-8 col-sm-8 col-xs-6">
                    <ul>
                        <li> <a href="index.php">Accueil</a></li>
                        <li> <a href="#footer">Nous Contacter</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>
    <!-- header -->

    <section class="client">
       <center><h2 class="section-title">Commandez Ici</h2></center> 
            <div class="line"><span></span></div>
        <div class="text">
            <p></p>
        </div>
    </section>
    <!-- <div class="alert alert-success" role="alert">
        <?php echo $messagesucces; ?>
    </div> -->
    <section>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data"> 
            <h1>Formulaire de Commande</h1>
            <hr>
            <div class="name-field">
                <div>
                    <label for="Name">Nom : </label>
                    <input type="text"  name="nom">
                </div>
                <div>
                    <label for="SurName">Prénoms : </label>
                    <input type="text"  name="prenom" >
                </div>
                <div>
                    <label for="e-mail">Adresse e-mail : </label>
                    <input type="e-mail" name="email" >
                </div>
                <div>
                    <label for="quantity">Quantité de sable (en tonnes) :</label>
                    <input type="text"  name="quantite" >
                </div>
                <div>
                    <label for="location">Lieu de Livraison :</label>
                    <input type="text"  name="lieu">
                </div>
                <div>
                    <label for="time">Heure de Livraison :</label>
                    <input type="time" placeholder="Heure_de_livraison" name="heure">        
                </div>
                <div>

                </div>
            </div>
            <br> <br>
            <button type="submit" >Envoyer</button>
        </form>

    </section>
    <br><br> <br><br><br><br><br><br>

    <footer id="footer">
        <ul>
            <li><img src="./images/fb.png" alt="Facebook"> Facebook</li>
            <li><img src="./images/insta.jpg" alt="Instagram"> Instagram</li>
            <li><img src="./images/gmail.png" alt="gmail"> E-mail</li>
        </ul>
        <center><p class="copyright">&copy; Untitled. All rights reserved. Design by SBS-sarl.</p></center>
    </footer>
    <script src="js/vendors/jquery-3.3.1.min.js"></script>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
</body>
</html>
 
