<?php
//connexion à la base de données
$servername = "localhost";
$username = "utilisateur";
$password = "mot_de_passe";
$dbname = "ma_base_de_données";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connexion échouée : ". $conn->connect_error);
}

//traitement de la commande 

$IdClient = $_POST['Id_Client'];
$Quantité_de_sable = $_POST['Quantité_de_sable'];
$Heure_de_livraison = $_POST['Heure_de_livraison'];
$Lieu_de_livraison = $_POST['Lieu_de_livraison'];

$sql = "INSERT INTO commandes (Id_Client, Quantité_de_sable, Heure_de_livraison, Lieu_de_livraison ) VALUES ('$IdClient', '$Quantité_de_sable', '$Heure_de_livraison', '$Lieu_de_livraison')";

if($conn->query($sql) === TRUE) {
    echo "Commande enregistrée avec succès. ";
}else{
    echo "Erreur lors de l'enregistrement de la commande : " . $conn->error; 
}

$conn->close();
>